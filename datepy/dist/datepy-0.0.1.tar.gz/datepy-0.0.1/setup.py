import setuptools
from setuptools import setup, find_packages
 
 
setup(name='datepy',
      version='0.0.1',
      url='',
      license='MIT',
      author='Imaad',
      author_email='imaadmkhan1@gmail.com',
      description='Date Utilities',
	  packages=setuptools.find_packages(),
	  include_package_data=True)